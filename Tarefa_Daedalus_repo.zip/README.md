# Tarefa Daedalus

Repositório gerado a partir do PDF *Tarefa Daedalus* (arquivo original incluído).
Conteúdo: exercícios e respostas para os computadores hipotéticos **Ahmes** e **Ramses**.

Referência do arquivo original: Tarefa Daedalus.pdf. (Fonte: arquivo enviado pelo usuário). fileciteturn0file0

## Estrutura
- `src/ahmes.asm` - códigos/respostas para o computador **Ahmes**
- `src/ramses.asm` - códigos/respostas para o computador **Ramses**
- `docs/Tarefa_Daedalus.pdf` - PDF original
- `NOTAS.md` - observações sobre conteúdo e como testar

## Como usar
1. Descompacte o arquivo e entre na pasta:
   ```bash
   unzip Tarefa_Daedalus_repo.zip
   cd Tarefa_Daedalus_repo
   ```
2. Inicialize um repositório Git e faça o primeiro commit:
   ```bash
   git init
   git add .
   git commit -m "Import: Tarefa Daedalus (Ahmes & Ramses)"
   ```
3. Crie um repositório no GitHub (web ou `gh repo create`) e faça push:
   ```bash
   git remote add origin <URL_DO_REPO>
   git branch -M main
   git push -u origin main
   ```

## Licença
MIT - livre para uso educativo.
