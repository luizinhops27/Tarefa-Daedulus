NOTAS
- Este repositório foi gerado automaticamente a partir do PDF original.
- Os códigos foram mantidos como no conteúdo fornecido, com pequenas formatações para legibilidade.
- As instruções são pseudo-assembly para máquinas hipotéticas (Ahmes e Ramses).
- Testes: não há simuladores fornecidos aqui; é necessário um simulador compatível com a sintaxe usada.

Arquivo fonte original citado: Tarefa Daedalus.pdf. fileciteturn0file0
